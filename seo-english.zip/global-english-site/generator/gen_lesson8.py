# -*- coding: utf-8 -*-
from build import page, section, accordion, write

def scenario_body(context, spec_role, client_role, spec_phrases, client_phrases):
    sp = "".join(f"<span>{p}</span>" for p in spec_phrases)
    cp = "".join(f"<span>{p}</span>" for p in client_phrases)
    return f'''
    <p class="idea"><strong>Контекст:</strong> {context}</p>
    <h5>Роль специалиста</h5><p>{spec_role}</p>
    <h5>Роль клиента</h5><p>{client_role}</p>
    <h5>Фразы-помощники · специалист</h5><div class="chips">{sp}</div>
    <h5>Фразы-помощники · клиент</h5><div class="chips">{cp}</div>'''

scenarios = [
  dict(title="Guarantee Rankings or Refund", sub="финтех-стартап, требует письменных гарантий", body=scenario_body(
    "2-й месяц работы с финтех-стартапом (платформа для инвестиций). CEO клиента требует письменных гарантий топ-3 по 10 запросам, иначе хочет refund.",
    "Объяснить, почему невозможно гарантировать конкретные позиции. Предложить, что можно гарантировать (объём работ, качество, процессы). Не потерять клиента, не соглашаться на невозможное.",
    "Привык к KPI и гарантиям в других сферах бизнеса. «Я плачу деньги, хочу гарантии результата». CFO требует контракт с гарантиями.",
    ["I completely understand why you want guarantees — let me explain why SEO is different…", "No legitimate agency can guarantee specific rankings — here's why…",
     "What we CAN guarantee is the quality and volume of work…", "Think of it like a fitness trainer — they guarantee the plan, not the specific weight loss…"],
    ["I need guarantees. If I'm paying, I want guaranteed results", "PPC guarantees impressions and clicks. Why can't you guarantee rankings?",
     "Other agencies offered to guarantee top 3 positions", "What am I paying for if there's no guarantee?"],
  )),
  dict(title="Spam Agency Promises", sub="крипто, конкурент обещает топ-1 за 30 дней", body=scenario_body(
    "Клиент (криптообменник) получил cold email от другого агентства: «Мы гарантируем топ-1 за 30 дней за $500/месяц». Показывает письмо и спрашивает: «Почему они так дёшево и быстро, а вы дорого и долго?»",
    "Объяснить red flags спам-предложений. Показать разницу между legitimate и scam agencies. Не говорить плохо о конкуренте напрямую, показать риски.",
    "Предложение выглядит очень привлекательно, не эксперт в SEO. «$500 vs ваши $3000», «30 дней vs ваши 6 месяцев» — цифры говорят сами за себя.",
    ["I'm glad you showed me this — let me point out some major red flags here…", "Top 1 in 30 days is literally impossible without breaking Google's rules…",
     "This pricing suggests they're using automated spam tactics, not real SEO…", "Short term gain, long term disaster — your site could get banned…"],
    ["Look at this email — they guarantee top 1 in 30 days for $500!", "Why are you 6x more expensive and take 6x longer?",
     "Maybe we're overpaying for SEO?", "What's the catch? This sounds like a great deal"],
  )),
  dict(title="Copy Competitor Strategy", sub="travel-платформа, требует скопировать конкурента", body=scenario_body(
    "Клиент (платформа авторских туров) нашёл, что конкурент ранжируется хорошо. Требует: «Просто скопируйте что они делают! Те же ключевые слова, тот же контент, те же страницы!»",
    "Объяснить, почему копирование 1-в-1 не работает и может навредить. Показать, что нужно адаптировать, а не копировать. Предложить, как использовать инсайты конкурента правильно.",
    "Увидел, что конкурент успешен — логично делать то же самое. «Зачем изобретать велосипед?» Не понимает, почему специалист усложняет.",
    ["I understand the logic — if it works for them, why not for us? Let me explain…", "Copying content is actually a penalty risk — Google detects duplicate content…",
     "What works for them might not work for us — different domain authority, backlinks, history…", "We should learn FROM them, not copy them directly…"],
    ["Just copy what they're doing — it clearly works!", "Use the same keywords, same page structure, same everything",
     "I don't need creativity, I need what works", "They're ranking #1, we should do exactly what they do"],
  )),
  dict(title="Micromanaging SEO Expert", sub="SaaS, клиент начитался блогов", body=scenario_body(
    "Клиент (SaaS для маркетологов) сам прочитал много SEO-блогов. Теперь пытается управлять каждой деталью: «Я читал, что keyword density должна быть 2.5%», «Этот блогер сказал делать по-другому».",
    "Уважительно установить экспертность. Объяснить, что не все SEO-советы в блогах актуальны или правильны. Найти баланс между тем, чтобы прислушиваться к клиенту и держать контроль над стратегией.",
    "Прочитал Backlinko, Ahrefs blog, Moz — считает, что разбирается в SEO. Постоянно присылает статьи, проверяет каждое решение специалиста.",
    ["I appreciate that you're staying informed — that's actually great…", "This advice was accurate in 2018, but Google has changed significantly since then…",
     "Keyword density is actually outdated — Google uses semantic understanding now…", "Let's set up a process where you can share ideas and we'll evaluate them…"],
    ["I read on Backlinko that we should do [tactic] — why aren't we doing this?", "This SEO expert says keyword density should be exactly 2.5%",
     "I found this tool that competitors use — why don't we use it?", "I need to understand and approve every decision"],
  )),
  dict(title="Budget Cut Mid-Project", sub="e-commerce, урезание бюджета на 50%", body=scenario_body(
    "3-й месяц работы с e-commerce платформой (товары для хобби). Клиент сообщает: «Нам нужно сократить бюджет на 50% начиная со следующего месяца. Но мы хотим те же результаты».",
    "Объяснить, что 50% cut = 50% меньше работы. Предложить, что можно сохранить в рамках нового бюджета, а что придётся приостановить. Быть честным о влиянии на результаты.",
    "У компании финансовые трудности, бюджет урезан по всем направлениям. Понимает, что сложно, но «у нас нет выбора». Надеется, что специалист «найдёт способ» сделать ту же работу дешевле.",
    ["I understand this is a difficult situation for your company…", "Let me be transparent — 50% budget means 50% less work…",
     "Here's what we can prioritize with the reduced budget…", "This will slow down progress, but we can maintain what we've built…"],
    ["We need to cut the budget by 50% starting next month", "But we still need the same results — can you make it work?",
     "Maybe there's a more efficient way to do the work?", "We have no choice — it's this or cancel completely"],
  )),
  dict(title="Sudden Rankings Drop Panic", sub="запасной · образовательная платформа, обвал позиций за ночь", body=scenario_body(
    "Клиент (образовательная онлайн-платформа) звонит в панике: «Все наши топ-10 позиции упали до 30–40 за ночь! Что вы сделали?! Это катастрофа!» Был Google algorithm update накануне.",
    "Успокоить клиента. Быстро проанализировать, что произошло — algorithm update, техническая проблема или что-то ещё. Показать план восстановления, не паниковать самому.",
    "Traffic упал на 60%. В панике: «Мы только что запустили новый курс, и нужен трафик СЕЙЧАС!» Подозревает, что специалист что-то сломал, или что это negative SEO от конкурентов.",
    ["I understand this is alarming — let me analyze what happened…", "Google rolled out a major algorithm update yesterday — this affected many sites…",
     "Algorithm updates typically stabilize within 2-3 weeks…", "Let me show you that we didn't make any changes that would cause this…"],
    ["All our rankings dropped overnight! What did you do?!", "Did you change something without telling me?",
     "Is this negative SEO from competitors?", "Fix this immediately or we're canceling the contract!"],
  )),
  dict(title="ROI Justification to Board", sub="запасной · финтех, презентация для совета директоров", body=scenario_body(
    "Клиент (финтех-стартап) доволен работой, но: «Наш Board of Directors запросил детальное ROI-обоснование всех маркетинговых каналов. Мне нужно доказать, что SEO worth it. Помогите подготовить presentation».",
    "Помочь подготовить убедительный case для Board. Показать ROI не только в прямых conversions, но и в brand awareness, long-term value. Дать конкретные цифры и projections.",
    "Board скептичен к SEO, видит, что PPC даёт immediate results. CFO спрашивает: «Почему мы тратим $5K/месяц на SEO, когда не видим прямых conversions?» Нервничает — если не убедит Board, бюджет урежут.",
    ["Let's build a strong case together — here's the data we'll present…", "SEO's ROI compounds over time — let me show you the trajectory…",
     "Compared to PPC, our cost per acquisition is actually 60% lower…", "Let me prepare a Board-ready presentation with clear metrics…"],
    ["Board of Directors wants detailed ROI justification for SEO", "CFO says 'show me direct revenue attribution or we cut the budget'",
     "I believe in SEO but I need hard numbers for the presentation", "If I don't convince them, SEO budget gets cut by 70%"],
  )),
]

sec = section("scenarios", "7 сценариев", "теперь специалист и клиент меняются местами — импровизация 5–7 минут",
              accordion(scenarios, first_open=False))

body = f'''<section id="intro">
  <div class="wrap">
    <h2>Формат</h2>
    <p class="section-kicker">без подготовки — чистая импровизация</p>
    <div class="info-card"><p class="idea">5–7 минут на сценарий. Роли распределены заранее (см. подзаголовок каждой карточки), но при повторном прогоне можно меняться местами.</p></div>
  </div>
</section>
{sec}'''

html = page(
    title="Урок 8 — Role Play: Reverse Roles",
    desc="7 новых сценариев ролевой игры: гарантии позиций, спам-агентства, копирование конкурентов, микроменеджмент клиента, урезание бюджета, паника из-за обвала позиций, ROI перед советом директоров.",
    brand="Global English · Урок 8",
    eyebrow="Урок 8 из курса «Global English для SEO»",
    h1="Role Play: Reverse Roles",
    lede="Новые сценарии — от требования письменных гарантий до презентации ROI совету директоров. Роли меняются, давление растёт.",
    navlinks=[("#intro","Формат"), ("#scenarios","Сценарии")],
    body=body,
    prev_href="/lessons/7/", prev_label="← Урок 7: Role Play",
    next_href="/lessons/9/", next_label="Урок 9: Фразовые глаголы →",
)
write("lessons/8/index.html", html)
